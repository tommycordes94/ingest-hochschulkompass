from trdpipe.structify_publish.structify import BaseStructifier

class Structifier(BaseStructifier):

    datasource = "hollywood.actors"

    def structify(self):
        pass