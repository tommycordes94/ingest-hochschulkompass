import pathlib
import glob
import os
from datetime import datetime
from trdpipe.gcpclient.cloudstorage import CSClient


class BasePipe():

    STORAGE_GCP = "gcp"
    STORAGE_LOCAL = "local"

    def __init__(
        self, 
        config: dict, 
        params: dict = None,
        subsrc: str = None):
        self.config = config
        self.params = params
        self.subsrc = subsrc
        self.workdir = config.get(
            'workdir', '/tmp') if config is not None else None

    def _findLatestDate(self, dataset: str, f_ext: str, stage: str) -> str:
        fls = self._collectFiles(
            dataset=dataset,
            f_ext=f_ext,
            stage=stage)

        return self._findFilesMaxDate(fls)

    def _findLatest(self, dataset: str, f_ext: str, stage: str) -> str:
        fls = self._collectFiles(
            dataset=dataset,
            f_ext=f_ext,
            stage=stage)

        latestF = self._findFileWithMaxDate(fls)
        print(fls)

        if self._getStorage() == self.STORAGE_GCP:
            gsPath = self._getPath(stage=stage)
            csClient = CSClient(bucket=self._extractBucket(gsPath))
            return csClient.downloadBlob(path=latestF, targetPath=f"{self.workdir}/")
        else:
            return latestF

    def _collectFiles(self, dataset: str, f_ext: str, stage: str):
        if self._getStorage() == self.STORAGE_GCP:
            fls = self._collectGCPFiles(path=self._getPath(
                stage=stage), dataset=dataset, f_ext=f_ext)
        else:
            path = pathlib.Path(self._getPath(stage=stage))
            if path.exists() == False:
                raise ValueError(f"path {path} doesn't exist")
            glxpr = f"{path.resolve()}/{dataset}*.{f_ext}"
            fls = glob.glob(glxpr)

        if len(fls) == 0:
            return None

        return fls

    def _findFilesMaxDate(self, files: list) -> str:
        if files is None:
            return None
        dates = [self._extractDateFromFilename(f)
                 for f in files if self._extractDateFromFilename(f) is not None]
        if len(dates) == 0:
            raise ValueError(
                f"no files found matching the format '<filename>_%Y%m%d.<extension>")
        return datetime.strftime(max(dates), "%Y%m%d")

    def _findFileWithMaxDate(self, files: list):
        maxDateStr = self._findFilesMaxDate(files)
        if maxDateStr is None:
            return None
        return [f for f in files if maxDateStr in f][0]

    def _extractDateFromFilename(self, f):
        try:
            fileRoot = os.path.split(f)[1].split('.')[0]
            return datetime.strptime(fileRoot[-8:], '%Y%m%d')
        except ValueError:
            return None

    def _getPath(self, stage: str) -> str:
        if 'base_path' not in self.config:
            raise ValueError("no base_path provided in config")
        subPath = self.datasource.replace(".", "/")
        fullPath = f"{self.config['base_path']}/{stage}/{subPath}"
        if self.subsrc is None:
            return fullPath
        else:
            return f"{fullPath}/{self.subsrc}"

    def _getStorage(self):
        if 'base_path' not in self.config:
            raise ValueError("no base_path provided in config")
        if self.config['base_path'].startswith("gs://"):
            return self.STORAGE_GCP
        else:
            return self.STORAGE_LOCAL

    def _collectGCPFiles(self, path: str, dataset: str, f_ext: str):
        print("path:", path)
        csClient = CSClient(bucket=self._extractBucket(path))
        p = self._extractBucketPath(path)
        glxpr = f"{p}/{dataset}*.{f_ext}"
        return csClient.listBlobs(path=p, fileFilter=glxpr)

    def _extractBucket(self, path: str):
        return path.replace("gs://", "").split("/")[0]

    def _extractBucketPath(self, path: str):
        p = path.replace("gs://", "")
        folders = [p1 for p1 in p.split("/")]
        return "/".join([p for p in folders[1:]])

    def _collectSubSources(self, stage):
        srcs = None
        if self._getStorage() == self.STORAGE_GCP:
            path = self._getPath(
                stage=stage)
            srcs = self._collectGCPSubSources(path=path)
            srcs = [s.replace(
                self._extractBucketPath(path)+"/", '').split(
                    '/')[0] for s in srcs]
        else:
            path = pathlib.Path(self._getPath(stage=stage))
            if path.exists() == False:
                raise ValueError(f"path {path} doesn't exist")
            srcs = glob.glob(f"{path}/*/", recursive=False)
            srcs = [os.path.split(s[:-1])[1] for s in srcs]

        if len(srcs) == 0:
            return None

        return srcs

    def _collectGCPSubSources(self, path: str):
        print(self._extractBucket(path))
        csClient = CSClient(bucket=self._extractBucket(path))
        p = self._extractBucketPath(path)
        glxpr = f"{p}/*"
        print(glxpr)
        return csClient.listBlobs(path=p, fileFilter=glxpr)
