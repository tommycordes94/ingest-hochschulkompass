from google.cloud import bigquery


class BigQueryLoader():

    """
    Loads files to BigQuery.
    """

    def __init__(self, project, dataset):
        """
        Constructor

        project: google project which contains the bq dataset
        dataset: bigquery dataset which contains the table to write to
        """
        self.project = project
        self.dataset = dataset

    def loadFromUri(self, 
                    table_id:str,
                    uri:str, 
                    source_format:str=bigquery.SourceFormat.PARQUET,
                    write_disposition:str=bigquery.WriteDisposition.WRITE_TRUNCATE):
        """

        uri: uri of the file to be loaded, e.g. 
            'gs://cloud-samples-data/bigquery/us-states/us-states.parquet'

        table_id: table_id of the table to create or load to

        source_format: format of the file to be loaded, e.g. bigquery.SourceFormat.PARQUET

        write_disposition: write disposition of the request, e.g. WRITE_TRUNCATE
            details: https://googleapis.dev/python/bigquery/latest/generated/google.cloud.bigquery.job.WriteDisposition.html
        """

        # Construct a BigQuery client object.
        client = bigquery.Client()

        job_config = bigquery.LoadJobConfig(source_format=source_format, 
                                            write_disposition=write_disposition)

        full_table_id = f"{self.project}.{self.dataset}.{table_id}"
        load_job = client.load_table_from_uri(
            uri, full_table_id, job_config=job_config
        )  # Make an API request.

        load_job.result()  # Waits for the job to complete.

        destination_table = client.get_table(full_table_id)
        print("Loaded {} rows.".format(destination_table.num_rows))