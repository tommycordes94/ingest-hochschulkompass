import pyarrow as pa
import pandas as pd
import numpy as np

from trdpipe.structify_publish.validator import Validator
from trdpipe.structify_publish.test.hollywood import actors

from trdpipe.structify_publish.convert import convert_schema_js_to_pyarrow


def test_jsonschema_2_pyarrow():

    data = pd.DataFrame(data={
        "actor_id":[1, 2, 3],
        "name":[np.nan, np.nan, np.nan],
        "house_size":[100, 200, 300],
        "district":["A", "B", "C"],
        "timestamp": [1654128000000000000, 1654128000000000000, 1654128000000000000]
    })

    v = Validator()
    schema = v.getJsonSchema(actors.__file__, "houses")
    pa_schema = convert_schema_js_to_pyarrow(data, schema)
    #check if house size exists
    assert pa_schema.field('house_size') is not None
    assert pa_schema.field('house_size').type == pa.type_for_alias("int64")
    #check if name is string, although the pandas type is float
    assert pa_schema.field('name') is not None
    assert pa_schema.field('name').type == pa.type_for_alias("string")
    #check if district is present and of type string, although it is not defined in the json schema
    assert pa_schema.field('name') is not None
    assert pa_schema.field('name').type == pa.type_for_alias("string")
    #check if timestamp is of type timestamp in case format 'unix-timestamp' is provided
    assert pa_schema.field('timestamp') is not None
    assert pa_schema.field('timestamp').type == pa.timestamp('ms')

