import pathlib
import glob
import os
from datetime import datetime
import shutil
from pandas import DataFrame
import json
import sys

from trdpipe.gcpclient.cloudstorage import CSClient
from trdpipe.structify_publish.pipe import BasePipe

from .validator import Validator


class StructifierMeta(type):
    """A Structifier metaclass that will be used for Structifier class creation.
    """
    def __instancecheck__(cls, instance):
        return cls.__subclasscheck__(type(instance))

    def __subclasscheck__(cls, subclass):
        return (hasattr(subclass, 'structify') and
                callable(subclass.structify) and
                hasattr(subclass, 'datasource'))


class BaseStructifier(BasePipe, metaclass=StructifierMeta):

    STAGE_RAW = "0_raw"
    STAGE_PUBL = "1_structified"

    FORMAT_CSV = "csv"
    FORMAT_PARQUET = "parquet"

    def __init__(
        self, 
        config: dict, 
        params: dict = None,
        subsrc: str = None):
        super().__init__(
            config=config,
            params=params, 
            subsrc=subsrc)

    def _push(
            self,
            dataset: str,
            data: DataFrame,
            timestamp: str,
            formats: str,
            create_latest: bool = True,
            add_timestamp2data: bool = True,
            validate: bool = True,
            schema_name: str = None):

        if dataset is None or len(dataset) == 0:
            raise ValueError("data cannot be pushed - no dataset provided")
        if '.' in dataset:
            raise ValueError(
                "data cannot be pushed - dataset invalid (please do not use periods -> (.))")
        if data is None:
            raise ValueError("data cannot be pushed - no data provided")
        try:
            ts = datetime.strptime(timestamp, "%Y%m%d")
        except ValueError:
            raise ValueError(
                "data cannot be pushed - timestamp invalid, provide it in the format '%Y%m%d'")
        if add_timestamp2data:
            if 'timestamp' not in data.columns:
                data["timestamp"] = ts
            else:
                msg = "data cannot be pushed - already contains a timestamp."
                msg = msg + " consider setting 'add_timestamp2data' to false"
                raise ValueError(msg)

        v = Validator()
        schema = v.getJsonSchema(
            root=sys.modules[self.__class__.__module__].__file__,
            dataset=schema_name if schema_name is not None else dataset)
        if validate:
            v.validate(data, schema)

        for f in formats.split(","):
            self.__pushFormat(
                dataset=dataset,
                data=data,
                timestamp=timestamp,
                format=f.strip(),
                create_latest=create_latest)

        self.__pushSchema(
            dataset=dataset,
            timestamp=timestamp,
            schema=schema,
            create_latest=create_latest)

    def __pushSchema(
            self,
            dataset,
            timestamp,
            schema,
            create_latest):
        filename = f"{self.workdir}/meta_{dataset}_{timestamp}.json"
        with open(filename, 'w') as f:
            json.dump(schema, f)

        self.__pushFile(filename, timestamp, create_latest)

    def __pushFile(self, filename, timestamp, create_latest):
        # make copy to 'latest' version
        if create_latest:
            filename_latest = filename.replace(timestamp, "latest")
            shutil.copyfile(filename, filename_latest)

        # copy or upload
        if self._getStorage() == self.STORAGE_GCP:
            # upload to gcp
            gsPath = self._getPath(stage=self.STAGE_PUBL)
            csClient = CSClient(bucket=self._extractBucket(gsPath))
            csClient.upload(filename, self._extractBucketPath(gsPath))
            if create_latest:
                csClient.upload(filename_latest,
                                self._extractBucketPath(gsPath))
        else:
            # local copy to target folder
            path = pathlib.Path(self._getPath(stage=self.STAGE_PUBL))
            if path.exists() == False:
                os.makedirs(path)
            shutil.copyfile(filename, path.joinpath(
                os.path.split(filename)[1]))
            if create_latest:
                shutil.copyfile(filename_latest, path.joinpath(
                    os.path.split(filename_latest)[1]))

    def __pushFormat(
            self,
            dataset: str,
            data: DataFrame,
            timestamp: str,
            format: str,
            create_latest: bool):

        filename = f"{self.workdir}/{dataset}_{timestamp}.{format}"
        if format == self.FORMAT_CSV:
            data.to_csv(filename, index=False)
        elif format == self.FORMAT_PARQUET:
            data.to_parquet(filename, index=False)
        else:
            raise ValueError(
                f"data cannot be pushed - unknown data format {format}")

        self.__pushFile(filename, timestamp, create_latest)

    
