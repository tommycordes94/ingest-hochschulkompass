import pathlib
import glob
import os
from datetime import datetime
import shutil
from pandas import DataFrame
import json
import sys

from trdpipe.gcpclient.cloudstorage import CSClient

from .validator import Validator


class WranglerMeta(type):
    """A Wrangler metaclass that will be used for wrangler class creation.
    """
    def __instancecheck__(cls, instance):
        return cls.__subclasscheck__(type(instance))

    def __subclasscheck__(cls, subclass):
        return (hasattr(subclass, 'wrangle') and
                callable(subclass.wrangle) and
                hasattr(subclass, 'datasource'))


class BaseWrangler(metaclass=WranglerMeta):

    STAGE_RAW = "0_raw"
    STAGE_PUBL = "1_structified"

    STORAGE_GCP = "gcp"
    STORAGE_LOCAL = "local"

    FORMAT_CSV = "csv"
    FORMAT_PARQUET = "parquet"

    def __init__(self, config: dict, params: dict, subsrc: str = None):
        self.config = config
        self.params = params
        self.subsrc = subsrc
        self.workdir = config.get(
            'workdir', '/tmp') if config is not None else None

    def _push(
            self,
            dataset: str,
            data: DataFrame,
            timestamp: str,
            formats: str,
            create_latest: bool = True,
            add_timestamp2data: bool = True,
            validate: bool = True,
            schema_name: str = None):

        if dataset is None or len(dataset) == 0:
            raise ValueError("data cannot be pushed - no dataset provided")
        if '.' in dataset:
            raise ValueError(
                "data cannot be pushed - dataset invalid (please do not use periods -> (.))")
        if data is None:
            raise ValueError("data cannot be pushed - no data provided")
        try:
            ts = datetime.strptime(timestamp, "%Y%m%d")
        except ValueError:
            raise ValueError(
                "data cannot be pushed - timestamp invalid, provide it in the format '%Y%m%d'")
        if add_timestamp2data:
            if 'timestamp' not in data.columns:
                data["timestamp"] = ts
            else:
                msg = "data cannot be pushed - already contains a timestamp."
                msg = msg + " consider setting 'add_timestamp2data' to false"
                raise ValueError(msg)

        v = Validator()
        schema = v.getJsonSchema(
            root=sys.modules[self.__class__.__module__].__file__,
            dataset=schema_name if schema_name is not None else dataset)
        if validate:
            v.validate(data, schema)

        for f in formats.split(","):
            self.__pushFormat(
                dataset=dataset,
                data=data,
                timestamp=timestamp,
                format=f.strip(),
                create_latest=create_latest)

        self.__pushSchema(
            dataset=dataset,
            timestamp=timestamp,
            schema=schema,
            create_latest=create_latest)

    def __pushSchema(
            self,
            dataset,
            timestamp,
            schema,
            create_latest):
        filename = f"{self.workdir}/meta_{dataset}_{timestamp}.json"
        with open(filename, 'w') as f:
            json.dump(schema, f)

        self.__pushFile(filename, timestamp, create_latest)

    def __pushFile(self, filename, timestamp, create_latest):
        # make copy to 'latest' version
        if create_latest:
            filename_latest = filename.replace(timestamp, "latest")
            shutil.copyfile(filename, filename_latest)

        # copy or upload
        if self.__getStorage() == self.STORAGE_GCP:
            # upload to gcp
            gsPath = self.__getPath(stage=self.STAGE_PUBL)
            csClient = CSClient(bucket=self.__extractBucket(gsPath))
            csClient.upload(filename, self.__extractBucketPath(gsPath))
            if create_latest:
                csClient.upload(filename_latest,
                                self.__extractBucketPath(gsPath))
        else:
            # local copy to target folder
            path = pathlib.Path(self.__getPath(stage=self.STAGE_PUBL))
            if path.exists() == False:
                os.makedirs(path)
            shutil.copyfile(filename, path.joinpath(
                os.path.split(filename)[1]))
            if create_latest:
                shutil.copyfile(filename_latest, path.joinpath(
                    os.path.split(filename_latest)[1]))

    def __pushFormat(
            self,
            dataset: str,
            data: DataFrame,
            timestamp: str,
            format: str,
            create_latest: bool):

        filename = f"{self.workdir}/{dataset}_{timestamp}.{format}"
        if format == self.FORMAT_CSV:
            data.to_csv(filename, index=False)
        elif format == self.FORMAT_PARQUET:
            data.to_parquet(filename, index=False)
        else:
            raise ValueError(
                f"data cannot be pushed - unknown data format {format}")

        self.__pushFile(filename, timestamp, create_latest)

    def _findLatestDate(self, dataset: str, f_ext: str, stage: str) -> str:
        fls = self.__collectFiles(
            dataset=dataset,
            f_ext=f_ext,
            stage=stage)

        return self.__findFilesMaxDate(fls)

    def _findLatest(self, dataset: str, f_ext: str, stage: str) -> str:
        fls = self.__collectFiles(
            dataset=dataset,
            f_ext=f_ext,
            stage=stage)

        latestF = self.__findFileWithMaxDate(fls)

        if self.__getStorage() == self.STORAGE_GCP:
            gsPath = self.__getPath(stage=stage)
            csClient = CSClient(bucket=self.__extractBucket(gsPath))
            return csClient.downloadBlob(path=latestF, targetPath=f"{self.workdir}/")
        else:
            return latestF

    def __collectFiles(self, dataset: str, f_ext: str, stage: str):
        if self.__getStorage() == self.STORAGE_GCP:
            fls = self.__collectGCPFiles(path=self.__getPath(
                stage=stage), dataset=dataset, f_ext=f_ext)
        else:
            path = pathlib.Path(self.__getPath(stage=stage))
            if path.exists() == False:
                raise ValueError(f"path {path} doesn't exist")
            glxpr = f"{path.resolve()}/{dataset}*.{f_ext}"
            fls = glob.glob(glxpr)

        if len(fls) == 0:
            return None

        return fls

    def __findFilesMaxDate(self, files: list) -> str:
        if files is None:
            return None
        dates = [self.__extractDateFromFilename(f)
                 for f in files if self.__extractDateFromFilename(f) is not None]
        if len(dates) == 0:
            raise ValueError(
                f"no files found matching the format '<filename>_%Y%m%d.<extension>")
        return datetime.strftime(max(dates), "%Y%m%d")

    def __findFileWithMaxDate(self, files: list):
        maxDateStr = self.__findFilesMaxDate(files)
        if maxDateStr is None:
            return None
        return [f for f in files if maxDateStr in f][0]

    def __extractDateFromFilename(self, f):
        try:
            fileRoot = os.path.split(f)[1].split('.')[0]
            return datetime.strptime(fileRoot[-8:], '%Y%m%d')
        except ValueError:
            return None

    def __getPath(self, stage: str) -> str:
        if 'base_path' not in self.config:
            raise ValueError("no base_path provided in config")
        subPath = self.datasource.replace(".", "/")
        fullPath = f"{self.config['base_path']}/{stage}/{subPath}"
        if self.subsrc is None:
            return fullPath
        else:
            return f"{fullPath}/{self.subsrc}"

    def __getStorage(self):
        if 'base_path' not in self.config:
            raise ValueError("no base_path provided in config")
        if self.config['base_path'].startswith("gs://"):
            return self.STORAGE_GCP
        else:
            return self.STORAGE_LOCAL

    def __collectGCPFiles(self, path: str, dataset: str, f_ext: str):
        csClient = CSClient(bucket=self.__extractBucket(path))
        p = self.__extractBucketPath(path)
        glxpr = f"{p}/{dataset}*.{f_ext}"
        return csClient.listBlobs(path=p, fileFilter=glxpr)

    def __extractBucket(self, path: str):
        return path.replace("gs://", "").split("/")[0]

    def __extractBucketPath(self, path: str):
        p = path.replace("gs://", "")
        folders = [p1 for p1 in p.split("/")]
        return "/".join([p for p in folders[1:]])

    def _collectSubSources(self, stage):
        srcs = None
        if self.__getStorage() == self.STORAGE_GCP:
            srcs = self.__collectGCPSubSources(path=self.__getPath(
                stage=stage))
        else:
            path = pathlib.Path(self.__getPath(stage=stage))
            if path.exists() == False:
                raise ValueError(f"path {path} doesn't exist")
            srcs = glob.glob(f"{path}/*/", recursive=False)
            
        srcs = [os.path.split(s[:-1])[1] for s in srcs]
        if len(srcs) == 0:
            return None

        return srcs

    def __collectGCPSubSources(self, path: str):
        csClient = CSClient(bucket=self.__extractBucket(path))
        p = self.__extractBucketPath(path)
        glxpr = f"{p}/*/"
        return csClient.listBlobs(path=p, fileFilter=glxpr)
