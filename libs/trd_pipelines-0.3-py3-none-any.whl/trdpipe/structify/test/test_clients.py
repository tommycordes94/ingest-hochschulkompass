import pytest
import pandas as pd
from trdpipe.structify.clients import UniversityMapperClient

def test_unimapper_client():
    url = "https://university-mapper-tcvu73msma-ey.a.run.app"
    umc = UniversityMapperClient(
        config={'uni_mapper_url': url})

    df = pd.DataFrame({'uni_id': [1, 2], 'uni_name': ['TU Berlin', 'Humboldt Uni Berlin']})

    df_result = umc.call(df=df, p_map_column='uni_name', p_match_threshold=0.6)

    assert df_result is not None
    assert df_result.shape[0] == 2

def test_unimapper_client_noconfig():
    with pytest.raises(ValueError):
        UniversityMapperClient(
            config={'uni_mapper_url': None})

    with pytest.raises(ValueError):
        UniversityMapperClient(
            config={})

    with pytest.raises(ValueError):
        UniversityMapperClient(
            config=None)

def test_unimapper_nodata():
    with pytest.raises(ValueError):
        url = "https://university-mapper-tcvu73msma-ey.a.run.app"
        umc = UniversityMapperClient(
            config={'uni_mapper_url': url})

        umc.call(df=None, p_map_column='uni_name', p_match_threshold=0.6)

def test_unimapper_nomapcolumn():
    with pytest.raises(ValueError):
        url = "https://university-mapper-tcvu73msma-ey.a.run.app"
        umc = UniversityMapperClient(
            config={'uni_mapper_url': url})

        df = pd.DataFrame({'uni_id': [1, 2], 'uni_name': ['TU Berlin', 'Humboldt Uni Berlin']})
        umc.call(df=df, p_map_column=None, p_match_threshold=0.6)

# invalid threshold
# wrong url