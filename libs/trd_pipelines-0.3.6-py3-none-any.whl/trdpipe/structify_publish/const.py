STORAGE_GCP = "gcp"
STORAGE_LOCAL = "local"

STAGE_RAW = "0_raw"
STAGE_PUBL = "1_struct"
STAGE_CALC = "2_calc"

FORMAT_CSV = "csv"
FORMAT_PARQUET = "parquet"
FORMAT_JSON = "json"
FORMAT_XLSX = "xlsx"

DATA_DOMAIN = "datadomain"
DATA_SOURCE = "datasource"
DATA_SUBSOURCE = "datasubsource"