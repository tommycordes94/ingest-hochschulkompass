import pathlib
import shutil
from trdpipe.structify_publish.const import (
    STORAGE_GCP, STORAGE_LOCAL, STAGE_RAW, 
    STAGE_PUBL, STAGE_CALC, 
    FORMAT_CSV, FORMAT_PARQUET, FORMAT_JSON, FORMAT_XLSX)
from src.trdpipe.structify_publish.pipe import BasePipe


def test_create_target_filename():
    basepath = pathlib.Path(__file__).parent.joinpath("data")
    p = BasePipe(config={
                'base_path':str(basepath)},
                 params={},
                 subsrc=None)
    p.datasource = "jobads.textkernel"
    tfs = p._BasePipe__create_target_file_names(
        filename="/tmp/aga_edition_mapping.parquet", 
        timestamp="20220502", 
        create_latest=False, 
        create_timebased=False,
        stage=STAGE_CALC)
    assert tfs is not None
    assert len(tfs) == 1 
    assert tfs[0][1] == f"{basepath}/2_calc/jobads/textkernel/aga_edition_mapping.parquet"

def test_create_target_filename_gcp():
    basepath = 'gs://trd-dwh-dev/datalake'
    p = BasePipe(config={
                'base_path':basepath},
                 params={},
                 subsrc=None)
    p.datasource = "jobads.textkernel"
    tfs = p._BasePipe__create_target_file_names(
        filename="/tmp/aga_edition_mapping.parquet", 
        timestamp="20220502", 
        create_latest=False, 
        create_timebased=False,
        stage=STAGE_CALC)
    assert tfs is not None
    assert len(tfs) == 1 
    assert tfs[0][1] == "/tmp/aga_edition_mapping.parquet"

def test_create_target_filename_2():
    basepath = pathlib.Path(__file__).parent.joinpath("data")
    p = BasePipe(config={
                'base_path':str(basepath)},
                 params={},
                 subsrc=None)
    p.datasource = "jobads.textkernel"

    tfs = p._BasePipe__create_target_file_names(
        filename="/tmp/aga_edition_mapping.parquet", 
        timestamp="20220502", 
        create_latest=True, 
        create_timebased=False,
        stage=STAGE_CALC)
    assert tfs is not None
    assert len(tfs) == 1 
    assert tfs[0][1] == f"{basepath}/2_calc/jobads/textkernel/aga_edition_mapping_latest.parquet"

def test_create_target_filename_2_gcp():
    basepath = 'gs://trd-dwh-dev/datalake'
    p = BasePipe(config={
                'base_path':str(basepath)},
                 params={},
                 subsrc=None)
    p.datasource = "jobads.textkernel"

    filename = pathlib.Path(__file__).parent.joinpath("testdata").joinpath("is_22_A_006_AT.parquet")
    tfs = p._BasePipe__create_target_file_names(
        filename=str(filename), 
        timestamp="20220502", 
        create_latest=True, 
        create_timebased=False,
        stage=STAGE_CALC)
    assert tfs is not None
    assert len(tfs) == 1 
    assert tfs[0][1] == str(pathlib.Path(__file__).parent.joinpath("testdata").joinpath("is_22_A_006_AT_latest.parquet"))

def test_create_target_filename_3():
    basepath = pathlib.Path(__file__).parent.joinpath("data")
    p = BasePipe(config={
                'base_path':str(basepath)},
                 params={},
                 subsrc=None)
    p.datasource = "jobads.textkernel"
    tfs = p._BasePipe__create_target_file_names(
        filename="/tmp/aga_edition_mapping.parquet", 
        timestamp="20220502", 
        create_latest=False, 
        create_timebased=True,
        stage=STAGE_CALC)
    assert tfs is not None
    assert len(tfs) == 1 
    assert tfs[0][1] == f"{basepath}/2_calc/jobads/textkernel/aga_edition_mapping_20220502.parquet"

def test_create_target_filename_3_gcp():
    basepath = 'gs://trd-dwh-dev/datalake'
    p = BasePipe(config={
                'base_path':str(basepath)},
                 params={},
                 subsrc=None)
    p.datasource = "jobads.textkernel"
    tfs = p._BasePipe__create_target_file_names(
        filename=str(pathlib.Path(__file__).parent.joinpath("testdata").joinpath("is_22_A_006_AT.parquet")),
        timestamp="20220502", 
        create_latest=False, 
        create_timebased=True,
        stage=STAGE_CALC)
    assert tfs is not None
    assert len(tfs) == 1 
    assert tfs[0][1] == str(pathlib.Path(__file__).parent.joinpath("testdata").joinpath("is_22_A_006_AT_20220502.parquet"))

def test_create_target_filename_4():
    basepath = pathlib.Path(__file__).parent.joinpath("data")
    p = BasePipe(config={
                'base_path':str(basepath)},
                 params={},
                 subsrc=None)
    p.datasource = "jobads.textkernel"
    tfs = p._BasePipe__create_target_file_names(
        filename="/tmp/aga_edition_mapping.parquet", 
        timestamp="20220502", 
        create_latest=True, 
        create_timebased=True,
        stage=STAGE_CALC)
    assert tfs is not None
    assert len(tfs) == 2
    assert tfs[0][1] == f"{basepath}/2_calc/jobads/textkernel/aga_edition_mapping_latest.parquet"
    assert tfs[1][1] == f"{basepath}/2_calc/jobads/textkernel/aga_edition_mapping_20220502.parquet"

def test_push_1():
    basepath = pathlib.Path(__file__).parent.joinpath("data")
    subpath = basepath.joinpath("2_calc/surveys_trendence/insol/22_A_006")
    
    #remove dir contents first
    if subpath.is_dir():
        shutil.rmtree(subpath)

    p = BasePipe(config={
                'base_path':str(basepath),
                'workdir':str(pathlib.Path(__file__).parent.joinpath("testdata"))},
                 params={},
                 subsrc="22_A_006")
    p.datasource = "surveys_trendence.insol"
    p._pushFile(
        filename=str(pathlib.Path(__file__).parent.joinpath("testdata").joinpath("is_22_A_006_AT.parquet")),
        timestamp="",
        create_latest=False,
        create_timebased=False,
        stage="2_calc"
    )
    assert subpath.joinpath("is_22_A_006_AT.parquet").is_file()

def test_push_2():
    basepath = pathlib.Path(__file__).parent.joinpath("data")
    subpath = basepath.joinpath("2_calc/surveys_trendence/insol/22_A_006")
    
    #remove dir contents first
    if subpath.is_dir():
        shutil.rmtree(subpath)

    p = BasePipe(config={
                'base_path':str(basepath),
                'workdir':str(pathlib.Path(__file__).parent.joinpath("testdata"))},
                 params={},
                 subsrc="22_A_006")
    p.datasource = "surveys_trendence.insol"
    p._pushFile(
        filename=str(pathlib.Path(__file__).parent.joinpath("testdata").joinpath("is_22_A_006_AT.parquet")),
        timestamp="",
        create_latest=True,
        create_timebased=False,
        stage="2_calc"
    )
    assert subpath.joinpath("is_22_A_006_AT_latest.parquet").is_file()

def test_push_3():
    basepath = pathlib.Path(__file__).parent.joinpath("data")
    subpath = basepath.joinpath("2_calc/surveys_trendence/insol/22_A_006")
    
    #remove dir contents first
    if subpath.is_dir():
        shutil.rmtree(subpath)

    p = BasePipe(config={
                'base_path':str(basepath),
                'workdir':str(pathlib.Path(__file__).parent.joinpath("testdata"))},
                 params={},
                 subsrc="22_A_006")
    p.datasource = "surveys_trendence.insol"
    p._pushFile(
        filename=str(pathlib.Path(__file__).parent.joinpath("testdata").joinpath("is_22_A_006_AT.parquet")),
        timestamp="20220502",
        create_latest=True,
        create_timebased=True,
        stage="2_calc"
    )
    assert subpath.joinpath("is_22_A_006_AT_latest.parquet").is_file()
    assert subpath.joinpath("is_22_A_006_AT_20220502.parquet").is_file()