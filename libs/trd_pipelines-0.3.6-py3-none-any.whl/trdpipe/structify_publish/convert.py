import pyarrow as pa
import pandas as pd

TYPE_MAPPING = {
    'string': 'utf8',
    'integer': 'int64',
    'number': 'float64',
    'boolean': 'bool',
}

def convert_schema_js_to_pyarrow(data: pd.DataFrame, json_schema):

    arrow_schema = pa.Schema.from_pandas(data, preserve_index=False)

    for k, v in json_schema.get('properties').items():
        # Get the JSON schema type name
        json_type_name = v.get('type')
        if type(json_type_name) == list:
            if 'null' in json_type_name:
                json_type_name.remove('null')
            json_type_name = json_type_name[0]

        # Look up the corresponding PyArrow type name
        arrow_type_name = TYPE_MAPPING[json_type_name]

        # Convert the PyArrow type name to a PyArrow type object
        arrow_type = pa.type_for_alias(arrow_type_name)

        # Replace existing type with referring type from json schema
        arrow_schema = arrow_schema.set(
            arrow_schema.get_field_index(k), 
            arrow_schema.field(k).with_type(arrow_type))

    return arrow_schema
