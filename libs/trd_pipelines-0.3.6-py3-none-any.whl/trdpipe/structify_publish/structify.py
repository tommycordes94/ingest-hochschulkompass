from trdpipe.structify_publish.pipe import BasePipe

class StructifierMeta(type):
    """A Structifier metaclass that will be used for Structifier class creation.
    """
    def __instancecheck__(cls, instance):
        return cls.__subclasscheck__(type(instance))

    def __subclasscheck__(cls, subclass):
        return (hasattr(subclass, 'structify') and
                callable(subclass.structify) and
                hasattr(subclass, 'datasource'))


class BaseStructifier(BasePipe, metaclass=StructifierMeta):

    def __init__(
        self, 
        config: dict, 
        params: dict = None,
        subsrc: str = None):
        super().__init__(
            config=config,
            params=params, 
            subsrc=subsrc)