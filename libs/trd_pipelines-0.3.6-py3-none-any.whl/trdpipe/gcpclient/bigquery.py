import pandas as pd
from google.cloud import bigquery

class BigQueryLoader():

    """
    Loads files to BigQuery.
    """

    def __init__(self, project, dataset):
        """
        Constructor

        project: google project which contains the bq dataset
        dataset: bigquery dataset which contains the table to write to
        """
        self.project = project
        self.dataset = dataset

    def loadFromUri(self, 
                    table_id:str,
                    uri:str, 
                    source_format:str=bigquery.SourceFormat.PARQUET,
                    write_disposition:str=bigquery.WriteDisposition.WRITE_TRUNCATE):
        """

        uri: uri of the file to be loaded, e.g. 
            'gs://cloud-samples-data/bigquery/us-states/us-states.parquet'

        table_id: table_id of the table to create or load to

        source_format: format of the file to be loaded, e.g. bigquery.SourceFormat.PARQUET

        write_disposition: write disposition of the request, e.g. WRITE_TRUNCATE
            details: https://googleapis.dev/python/bigquery/latest/generated/google.cloud.bigquery.job.WriteDisposition.html
        """

        # Construct a BigQuery client object.
        client = bigquery.Client()

        job_config = bigquery.LoadJobConfig(source_format=source_format, 
                                            write_disposition=write_disposition)

        full_table_id = f"{self.project}.{self.dataset}.{table_id}"
        load_job = client.load_table_from_uri(
            uri, full_table_id, job_config=job_config
        )  # Make an API request.

        load_job.result()  # Waits for the job to complete.

        destination_table = client.get_table(full_table_id)
        print("Loaded {} rows.".format(destination_table.num_rows))

    def changeSchema(self, table_id:str):
        # Construct a BigQuery client object.
        client = bigquery.Client()

        full_table_id = f"{self.project}.{self.dataset}.{table_id}"

        table = client.get_table(full_table_id)  # Make an API request.

        schema = {
            'university_name' : {
                'description' : 'the name of the university'
            }
        }

        original_schema = table.schema
        new_schema = []
        for c in original_schema:
            col_desc = schema.get(c.name)
            if col_desc is None:
                new_schema.append(c)
            else:
                new_schema.append(
                    bigquery.SchemaField(
                        c.name, 
                        c.field_type, 
                        description=col_desc.get('description')
                    )
                )
        
        #new_schema = original_schema[:]  # Creates a copy of the schema.
        #new_schema.append(bigquery.SchemaField("phone", "STRING"))

        table.schema = new_schema
        table = client.update_table(table, ["schema"])  # Make an API request.

class BigQueryReader():

    def __init__(self):
        pass

    def query(
        self, 
        query_string:str, 
        limit:int=-1) -> pd.DataFrame:

        bqclient = bigquery.Client()

        if limit > 0:
            query_string = f"{query_string} LIMIT {limit}"

        df = (
            bqclient.query(query_string)
            .result()
            .to_dataframe()
        )

        return df

    def query_chunks(self, query_string, page_size:int):
        bqclient = bigquery.Client()

        return (
            bqclient
            .query(query_string)
            .result(page_size=page_size)
            .to_dataframe_iterable()
        )