from urllib.error import HTTPError
import requests
import pandas as pd
import google.auth.transport.requests
import google.oauth2.id_token


class UniversityMapperClient():

    def __init__(self, config):
        if config is None:
            raise ValueError("no config provided for uni mapper client")
        self.service_url = config.get('uni_mapper_url')
        if self.service_url is None or len(self.service_url) == 0:
            msg = """no url for uni mapper service provided
            please specify it in the config (uni_mapper_url)
            """
            raise ValueError(msg)

    def call(self, df, p_map_column, p_match_threshold, response_columns:str=None):
        if df is None:
            raise ValueError("uni mapper cannot be called - no data provided")
        if p_map_column is None or len(p_map_column) == 0:
           raise ValueError("uni mapper cannot be called - no map column provided")

        if self.isLocal() == False:
            auth_req = google.auth.transport.requests.Request()
            id_token = google.oauth2.id_token.fetch_id_token(
                auth_req, self.service_url)
        else:
            id_token = "dummy"

        url = f"{self.service_url}/?map_column={p_map_column}"
        url = f"{url}&prob_threshold={p_match_threshold}"
        if response_columns is not None:
            url = f"{url}&response_columns={response_columns}"

        payload = df.to_json(orient="records")
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f"Bearer {id_token}"
        }

        response = requests.request("POST", url, headers=headers, data=payload)

        if response.status_code == 200:
            return pd.read_json(response.text)
        else:
            raise HTTPError(url, code=response.status_code,
                            msg="uni mapper returned error", 
                            hdrs=None, fp=None)

    def call_mapping_data(self, mapping_dataset:str):
        if mapping_dataset is None or len(mapping_dataset) == 0:
           raise ValueError("no mapping dataset provided")

        if self.isLocal() == False:
            auth_req = google.auth.transport.requests.Request()
            id_token = google.oauth2.id_token.fetch_id_token(
                auth_req, self.service_url)
        else:
            id_token = "dummy"

        url = f"{self.service_url}/?mapping_dataset={mapping_dataset}"
        payload = {}
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f"Bearer {id_token}"
        }

        response = requests.request("POST", url, headers=headers, data=payload)

        if response.status_code == 200:
            return pd.read_json(response.text)
        else:
            raise HTTPError(url, code=response.status_code,
                            msg="uni mapper returned error", 
                            hdrs=None, fp=None)

    def isLocal(self):
        for h in ['192.168.178.20', 'localhost', '127.0.0.1']:
            if h in self.service_url:
                return True

        return False