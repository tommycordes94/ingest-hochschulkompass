import pytest
from trdpipe.structify_publish.publish import BasePublisher

FILES = [
        'datalake/hollywood/meta_actors_20200101.json',
        'datalake/hollywood/meta_actors_latest.json',
        'datalake/hollywood/actors_latest.parquet',
        'datalake/hollywood/actors_20200101.parquet'
    ]

def test_find_meta_file():
    p = BasePublisher(config={}, datasource="")
    
    mf = p._BasePublisher__find_meta_file(
        f='datalake/hollywood/actors_20200101.parquet',
        files=FILES)
    assert mf == 'datalake/hollywood/meta_actors_20200101.json'

def test_find_meta_file_error():
    p = BasePublisher(config={}, datasource="")
    with pytest.raises(ValueError):
        mf = p._BasePublisher__find_meta_file(
            f='datalake/hollywood/actresses_20200101.parquet',
            files=FILES)

def test_get_data_meta_pairs():
    p = BasePublisher(config={}, datasource="")
    pairs = p._BasePublisher__get_data_meta_pairs(
        files=FILES
    )
    assert len(pairs.keys()) == 2
    assert pairs['datalake/hollywood/actors_latest.parquet'] \
        == 'datalake/hollywood/meta_actors_latest.json'

def test_get_gs_uri():
    p = BasePublisher(config={'base_path':'gs://trd-dwh-dev/datalake'}, datasource="")
    f = 'datalake/hollywood/actors_latest.parquet'
    gs_uri = p._BasePublisher__get_gs_uri(f)
    assert gs_uri == f'gs://trd-dwh-dev/{f}'

def test_collect_gcp_files():
    p = BasePublisher(config={'base_path':'gs://trd-dwh-dev/datalake'}, 
                 datasource="universities.che")
    files = p._collect_gcp_files()
    assert files is not None
    assert len(files.keys()) > 0